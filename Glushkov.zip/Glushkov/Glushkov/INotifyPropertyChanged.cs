﻿namespace Glushkov
{
    internal interface INotifyPropertyChanged
    {
    }
}